document.getElementById('userInput').addEventListener('keydown', function(event) {
  if (event.key === 'Enter') {
    // Prevent default form submission if in a form
    event.preventDefault();
    // Call a function or execute code here
    // console.log('User Input Submitted: ', this.value);
    
    // Display the value inside the displayText div
    const userInput = document.getElementById('userInput').value;
    document.getElementById('Query').textContent = userInput || "Please enter some text.";
    // Optionally, clear the input after submission
    this.value = '';
  }
});


document.getElementById('csvFileInput').addEventListener('change', function (event) {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function (e) {
      const csvContent = e.target.result;
      processCSV(csvContent);
    };
    reader.readAsText(file);
  }
});


// Back button functionality to reset to show all images
document.getElementById('backButton').addEventListener('click', function () {
  imagePaths = copyList(originImagePaths); 
  showImages(); 
});





function showSearchImages(searchInput) {
  const items = searchInput.split(/[ ,;]+/);
  const imageContainer = document.getElementById('imageContainer');
  imageContainer.innerHTML = ''; // Clear any previous images
  
  const newlist = []; 
  imagePaths = copyList(originImagePaths); 
  imagePaths.forEach((imagePath, index) => {
    const img = document.createElement('img');
    img.src = imagePath;
    img.alt = `Image ${index + 1}`;
    
    // Extract folder and file name from the image path
    const folderPath = imagePath.substring(0, imagePath.lastIndexOf(BACK));
    const fileName = imagePath.substring(imagePath.lastIndexOf(BACK) + 1);
    
    // Add title attribute to display the folder and file info on hover
    img.title = `Folder: ${folderPath}\nFile: ${fileName}`;
    
    img.addEventListener('click', () => displayImageRange(imagePath));  // Add click event
    
    if(items.some(substring => imagePath.includes(substring))) {
      imageContainer.appendChild(img);
      newlist.push(imagePath); 
    }
  });
  
  imagePaths = copyList(newlist); 
  
  // Show back button to allow user to go back to the initial state of showing all images
  document.getElementById('backButton').style.display = 'inline';
}
document.getElementById('searchButton').addEventListener('click', function() {
  // Get the value from the input field
  const searchInput = document.getElementById('searchInput').value;
  // textContainer.textContent += searchInput + '\n'; 
  showSearchImages(searchInput); 
  // textContainer.textContent += searchInput + '\n'; 
}); 


document.getElementById('showHistogram').addEventListener('click', function () {
  const values = []; 
  imagePaths = copyList(originImagePaths); 
  imagePaths.forEach((filePath, index) => {
    const baseFileName = filePath.substring(filePath.lastIndexOf(BACK) + 1, filePath.lastIndexOf('_'));
    values.push(baseFileName); 
  }); 
  showHistogram(values); 
  showPie(values); 
});